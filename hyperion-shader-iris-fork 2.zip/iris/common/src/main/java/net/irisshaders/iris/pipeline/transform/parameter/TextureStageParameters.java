package net.irisshaders.iris.pipeline.transform.parameter;

import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import net.irisshaders.iris.gl.texture.TextureType;
import net.irisshaders.iris.helpers.Tri;
import net.irisshaders.iris.pipeline.transform.Patch;
import net.irisshaders.iris.shaderpack.texture.TextureStage;

import java.util.Set;

public class TextureStageParameters extends Parameters {
	private final TextureStage stage;
	// WARNING: adding new fields requires updating hashCode and equals methods!

	public TextureStageParameters(Patch patch, TextureStage stage,
								  Object2ObjectMap<Tri<String, TextureType, TextureStage>, String> textureMap, Set<String> textureOverrides) {
		super(patch, textureMap, textureOverrides);
		this.stage = stage;
	}

	@Override
	public TextureStage getTextureStage() {
		return stage;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((stage == null) ? 0 : stage.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		TextureStageParameters other = (TextureStageParameters) obj;
		return stage == other.stage;
	}
}
