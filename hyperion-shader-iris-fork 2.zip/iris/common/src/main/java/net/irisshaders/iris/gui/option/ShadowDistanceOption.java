package net.irisshaders.iris.gui.option;

import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;
import net.minecraft.client.gui.components.AbstractWidget;

import java.util.function.Consumer;

public class ShadowDistanceOption<T> extends OptionInstance<T> {


	public ShadowDistanceOption(String captionId, TooltipSupplier<T> tooltip, CaptionBasedToString<T> toString, ValueSet<T> values, T initialValue, ValueUpdateListener<? super T> onValueUpdate) {
		super(captionId, tooltip, toString, values, initialValue, onValueUpdate);
	}

	@Override
	public AbstractWidget createButton(Options options, int x, int y, int width) {
		AbstractWidget widget = super.createButton(options, x, y, width);

		widget.active = IrisVideoSettings.isShadowDistanceSliderEnabled();

		return widget;
	}
}
